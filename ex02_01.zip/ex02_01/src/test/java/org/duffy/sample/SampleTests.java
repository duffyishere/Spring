package org.duffy.sample;

public class SampleTests {
}
